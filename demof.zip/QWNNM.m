function[X]=QWNNM(Y,C,NSig,m,Iter)
    cY=q2cplx(double2q(Y)); % q2cplx:from quaternion to complex; double2q:from double to quaternion 
    [U,SigmaY,V]=svd(full(cY),'econ'); %对cY进行svd分解
    PatNum=size(Y,2);
    mNSig=sqrt(sum(NSig(:).^2)/length(NSig(:)));
    TempC=C*sqrt(PatNum)*2*mNSig^2;
    [SigmaX,svp]=ClosedQWNNM(SigmaY,TempC,eps);  
    cX=U(:,1:svp)*diag(SigmaX)*V(:,1:svp)';
    X=double2q(q2cplx(cX,'inverse'),'inverse'); %from quaternion to double
    X=real(X)+m;  % real part of complex number
    return;
